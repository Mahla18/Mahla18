import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-orange-50 text-gray-800">
      {/* Header */}
      <header className="bg-green-600 text-white p-4 shadow-md flex items-center justify-between">
        <h1 className="text-2xl font-bold">🌿 तुलसी गप</h1>
        <nav className="space-x-4">
          <a href="#home" className="hover:underline">Home</a>
          <a href="#products" className="hover:underline">Products</a>
          <a href="#about" className="hover:underline">About</a>
          <a href="#contact" className="hover:underline">Contact</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section id="home" className="flex flex-col items-center justify-center py-16 px-4 text-center">
        <motion.img
          src="/logo.png"
          alt="Tulsi Gap Logo"
          className="w-56 h-56 object-cover rounded-full shadow-lg mb-6"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1 }}
        />
        <h2 className="text-4xl font-bold mb-4">खस्ता कुरकुरे पापड़</h2>
        <p className="max-w-xl mb-6 text-lg">"पहले इस्तेमाल करें, फिर विश्वास करें" – 100% शुद्ध और घर जैसा स्वाद।</p>
        <Button className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-2xl shadow-md">
          Explore Products
        </Button>
      </section>

      {/* Products Section */}
      <section id="products" className="py-16 bg-white px-6">
        <h3 className="text-3xl font-bold text-center mb-10">हमारे प्रोडक्ट्स</h3>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { title: "उड़द पापड़", img: "https://upload.wikimedia.org/wikipedia/commons/f/f2/Urad_papad.jpg" },
            { title: "मसाला पापड़", img: "https://upload.wikimedia.org/wikipedia/commons/4/4d/Masala_papad.jpg" },
            { title: "चावल पापड़", img: "https://upload.wikimedia.org/wikipedia/commons/3/32/Rice_papad.jpg" },
          ].map((product, index) => (
            <Card key={index} className="rounded-2xl shadow-lg hover:shadow-xl transition">
              <CardContent className="p-4 flex flex-col items-center">
                <img src={product.img} alt={product.title} className="w-40 h-40 object-cover rounded-xl mb-4" />
                <h4 className="text-xl font-semibold">{product.title}</h4>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 px-6 text-center bg-gradient-to-r from-green-100 to-orange-100">
        <h3 className="text-3xl font-bold mb-6">हमारे बारे में</h3>
        <p className="max-w-2xl mx-auto text-lg">
          तुलसी गप में हम परंपरा और स्वाद को मिलाते हैं। हमारे पापड़ 100% प्राकृतिक सामग्री से बनाए जाते हैं,
          और हर एक बाइट में घर जैसा स्वाद मिलता है।
        </p>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 px-6 bg-white text-center">
        <h3 className="text-3xl font-bold mb-6">संपर्क करें</h3>
        <p className="mb-4">📞 9712951318</p>
        <p className="mb-4">✉️ mpundalik2@gmail.com</p>
        <p>📍 India</p>
      </section>

      {/* Footer */}
      <footer className="bg-green-700 text-white text-center py-4 mt-10">
        <p>© 2025 तुलसी गप | सभी अधिकार सुरक्षित</p>
      </footer>
    </div>
  );
}
